// router for checking password
var test=0
const express=require('express');
const Userdata=require('../model/user_data.js');
const Bookdata=require('../model/book_data.js');
const Transactiondata=require('../model/transaction_data.js');
// const addbookRouter=require('./addbookRouter')(test);
var pwdRouter=express.Router();
var bodyParser = require('body-parser');
pwdRouter.use(bodyParser.json());
pwdRouter.use(bodyParser.urlencoded({ extended: true }));
var res_1
var res_2
var books
var b_id
var t_id
var i=0
var indexarr=[]
var bookidarr=[]
var booknamearr=[]
var len


function router(test){


    pwdRouter.post('/',(req,res)=>{
        u_name=req.body.uname;
        pwd=req.body.psw;

        Bookdata.find({$and:[{ "app_status" : "approved" },{'status':"free"}]},function(err,result){
            if(err) throw err;
            books=result;    
        }).then(function(abc){});


        if(u_name=="admin"&&pwd=='admin')
        {
            Bookdata.find({"app_status":"pending"},function(err,result){
                if(err) throw err;
                res_2=result;
                if(result){
                res.render('admin',{res_2});
                }else
                res.send('No pending items');
            }).then(function(abc){});

            
        };
	    Userdata.findOne({$and:[{name:u_name},{password:pwd}]},function(error,result){
           if(result){
               res_1=result;
            res.render('user',{res_1,books});
           }
        //    else
        //    res.send('error no user found');

        }).then(function(abc){});
	
    })
    // pwdRouter.use('/addbook',addbookRouter);
    pwdRouter.get('/addbook',(req,res)=>{
        res.render('addbook',{res_1});
    })

    pwdRouter.post('/addbookdata',(req,res)=>{
       var item={
           title:req.body.title
           ,desc:req.body.desc
           ,status:req.body.status
           ,app_status:req.body.app_status
           ,owner_id:req.body.owner_id
           ,borr_id: '0'

       }
       var data=new Bookdata(item);
       data.save();
       res.render('user',{res_1,books});
    })

    pwdRouter.get('/back',(req,res)=>{
        res.render('user',{res_1,books});
    })

    pwdRouter.get('/remove/:id',(req,res)=>{
        var id =req.params.id;
        Bookdata.deleteOne({_id:id},function(req1,res1){
        }).then(function(abc){});
        Bookdata.find({"app_status":"pending"},function(err,result){
            if(err) throw err;
            res_2=result;
            if(result){
            res.render('admin',{res_2});
            }else
            res.send('No pending items');
        }).then(function(abc){});
                
    })

    pwdRouter.get('/approve/:id',(req,res)=>{
        var id =req.params.id;
        // //console.log('id');
        // //console.log(id);
        var query={ "_id":id };
        var data={ $set: { "app_status" : "approved" }};
        Bookdata.updateOne(query,data,function(err,res){
        }).then(function(abc){});
        Bookdata.find({"app_status":"pending"},function(err,result){
            if(err) throw err;
            res_2=result;
            if(result){
            res.render('admin',{res_2});
            }else
            res.send('No pending items');
        }).then(function(abc){});    
    })

    pwdRouter.get('/borrow/:id/:name',(req,res)=>{
        var id =req.params.id;
        var bname=req.params.name;
        console.log(bname);
        //console.log("free books before op");
        //console.log(books.length);
        var item={
            user_id:res_1._id,
            book_id:id,
            book_name:bname,
            status:"active"
        }
        var transaction=new Transactiondata(item);
        transaction.save();
        var query={ "_id":id };
        var data={ $set: { "status" : "borrowed" }};
        Bookdata.updateOne(query,data,function(err,res){
        }).then(function(abc){});
        Bookdata.find({$and:[{ "app_status" : "approved" },{'status':"free"}]},function(err,result){
            if(err) throw err;
            if(result){
            books=result;
            res.render('user',{res_1,books});
            }

        }).then(function(abc){});
    
    })

    pwdRouter.get('/mybooks',(req,res)=>{
        // 
        Bookdata.find({$and:[{ "owner_id" : res_1._id },{'status':"free"}]},function(err,result){
            if(err) throw err;
            if(result){
            mybooks=result;
            res.render('mybooks',{res_1,mybooks});
            }
        }).then(function(abc){});
        

    });

    pwdRouter.get('/borrowedbooks',(req,res)=>{
        Transactiondata.find({$and:[{user_id:res_1._id},{status:'active'}]},function(err,result) {
            len=result.length;
            if(result){
                for(var i=0;i<result.length;i++){
                booknamearr[i]=result[i].book_name;
                bookidarr[i]=result[i].book_id;
                indexarr[i]=result[i]._id;}
                
            }//end of if Result

            console.log("render1");
            console.log(booknamearr);
            res.render('borrowedbooks',{res_1,bookidarr,indexarr,booknamearr,len});
        })
    
    })//end of /borrowedbooks

    pwdRouter.get('/delete/:id',(req,res)=>{
        var id =req.params.id;
        Bookdata.deleteOne({_id:id},function(req1,res1){
        }).then(function(abc){});
        Bookdata.find({$and:[{ "owner_id" : res_1._id },{'status':"free"}]},function(err,result){
            if(err) throw err;
            if(result){
            mybooks=result;
            res.render('mybooks',{res_1,mybooks});
            }
        }).then(function(abc){});
    });

    pwdRouter.get('/return/:id1/:id2',(req,res)=>{
        var transactionindex=req.params.id1;
        var bookidindex=req.params.id2;
        Transactiondata.updateOne({'_id':transactionindex},{$set:{"status":"removed"}},function(err,res){});
        Bookdata.updateOne({'_id':bookidindex},{$set:{"status":"free"}},function(err,res){});
        Transactiondata.find({$and:[{user_id:res_1._id},{status:'active'}]},function(err,result) {
            console.log("result length");
            console.log(result.length);
            len=result.length;
            if(result.length>0){
                for(var i=0;i<result.length;i++){
                booknamearr[i]=result[i].book_name;
                bookidarr[i]=result[i].book_id;
                indexarr[i]=result[i]._id;}
                
            }//end of if Result
            else{len=0;}
            console.log("render2");
            console.log(booknamearr);
            res.render('borrowedbooks',{res_1,bookidarr,indexarr,booknamearr,len});
        })

    });







    return pwdRouter;
}
module.exports=router;
