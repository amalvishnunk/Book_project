﻿npm install ejs --save
npm install body-parser --save
npm install express --save
npm install mongoose --save
npm init

