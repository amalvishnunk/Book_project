// router for checking password
const express=require('express');
const Userdata=require('../model/user_data.js');
const pwdRouter=express.Router();
var app=express();

var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));



function router(test){

    pwdRouter.route('/').get((req,res)=>{
        u_name=req.param('uname');
        pwd=req.param('psw');

        if(u_name=="admin"&&pwd=='admin')
        {
            res.render('admin');
        };
	    Userdata.findOne({$and:[{name:u_name},{password:pwd}]},function(error,result){
           if(result){
            res.render('user',{result});
           }
           else
           res.send('error no user found');

        })
	




    })

    return pwdRouter;
}
module.exports=router;
